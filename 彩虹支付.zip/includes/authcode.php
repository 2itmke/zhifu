<?php
define('authcode','b93fe383ee98730f7f8d7e82ea67c5a0');

?>